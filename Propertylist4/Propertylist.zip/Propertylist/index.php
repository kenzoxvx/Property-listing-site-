<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RealEstate Connect - Where buyers meet realtors</title>
  <link rel="stylesheet" href="styles/index.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
  <div class="container">
    <header>
      <a href="#" class="logo"><img src="img/KENZOHOMES.png" alt="" style="width: 120px; heigth: 120px;"></a>
      
      <button class="hamburger">
        <span class="hamburger-line"></span>
        <span class="hamburger-line"></span>
        <span class="hamburger-line"></span>
      </button>
      
      <nav>
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
      
      <div class="overlay"></div>
    </header>
    
    <section class="hero" id="home">
      <div class="hero-content">
        <h1>Find Your Dream Home or Perfect Client</h1>
        <p>Connect with the right people in the real estate market. Whether you're looking to buy a property or you're a realtor looking for clients, we've got you covered.</p>
        
        <div class="signup-cards">
          <div class="card buyer-card">
            <div class="card-icon">
              <i class="fas fa-home"></i>
            </div>
            <h2>Property Buyer</h2>
            <p>Looking for your dream home? Sign up as a buyer to connect with top realtors in your area and get personalized property recommendations.</p>
            <a href="buyersregistration.php" class="btn btn-primary">Buyer Sign Up</a>
          </div>
          
          <div class="card realtor-card">
            <div class="card-icon">
              <i class="fas fa-key"></i>
            </div>
            <h2>Realtor</h2>
            <p>Are you a real estate professional? Sign up as a realtor to showcase your listings and connect with potential buyers who match your properties.</p>
            <a href="realtorregistration.php" class="btn btn-secondary">Realtor Sign Up</a>
          </div>
        </div>
      </div>
    </section>
    
    <section class="features" id="about">
      <h2>Why Choose RealEstateConnect</h2>
      <div class="feature-grid">
        <div class="feature-item">
          <div class="feature-icon">
            <i class="fas fa-search"></i>
          </div>
          <h3>Smart Matching</h3>
          <p>Our advanced algorithm matches buyers with properties and realtors that perfectly fit their needs and preferences.</p>
        </div>
        
        <div class="feature-item">
          <div class="feature-icon">
            <i class="fas fa-shield-alt"></i>
          </div>
          <h3>Secure Platform</h3>
          <p>Your data is protected with enterprise-grade security. Communicate and share information with peace of mind.</p>
        </div>
        
        <div class="feature-item">
          <div class="feature-icon">
            <i class="fas fa-star"></i>
          </div>
          <h3>Verified Listings</h3>
          <p>All properties and realtors on our platform are verified to ensure you only deal with legitimate opportunities.</p>
        </div>
      </div>
    </section>
  </div>
  
  <footer id="contact">
    <div class="footer-content">
      <p>© 2025 RealEstateConnect. All rights reserved.</p>
      <p>Connect with us on social media</p>
      <p>Contact number: 08068785827.</p>
      <div class="social-links">
        
        <a href="https://twitter.com/kenzodv" target="_blank"><i class="fab fa-twitter"></i></a>
        <a href="https://www.instagram.com/kenzo_dvv" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.tiktok.com/@kenzodv" target="_blank"><i class="fab fa-tiktok"></i></a>
      </div>
    </div>
  </footer>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      // Hamburger menu functionality
      const hamburger = document.querySelector('.hamburger');
      const nav = document.querySelector('nav');
      const overlay = document.querySelector('.overlay');
      const navLinks = document.querySelectorAll('nav ul li a');
      
      function toggleMenu() {
        hamburger.classList.toggle('active');
        nav.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.classList.toggle('no-scroll');
      }
      
      hamburger.addEventListener('click', toggleMenu);
      overlay.addEventListener('click', toggleMenu);
      
      // Close menu when clicking on nav links
      navLinks.forEach(link => {
        link.addEventListener('click', toggleMenu);
      });
      
      // Add hover effect to buttons
      const buttons = document.querySelectorAll('.btn');
      
      buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
          this.style.transform = 'scale(1.05)';
        });
        
        button.addEventListener('mouseleave', function() {
          this.style.transform = 'scale(1)';
        });
      });
      
      // Add scroll animation
      const animateOnScroll = function() {
        const elements = document.querySelectorAll('.feature-item');
        
        elements.forEach(element => {
          const position = element.getBoundingClientRect().top;
          const screenPosition = window.innerHeight / 1.3;
          
          if (position < screenPosition) {
            element.style.opacity = 1;
            element.style.transform = 'translateY(0)';
          }
        });
      };
      
      window.addEventListener('scroll', animateOnScroll);
      
      // Initialize animation
      animateOnScroll();
    });
  </script>
</body>
</html>