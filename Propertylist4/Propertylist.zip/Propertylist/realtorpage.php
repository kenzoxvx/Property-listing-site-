<?php 
    session_start();
    include("connect.php");

    if ( !isset($_SESSION['realtor_id']) ) {
        header("location: realtorregistration.php");
        exit();
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RealEstate Hub</title>
    <link rel="stylesheet" href="styles/realtorpage.css">
    
</head>
<body>
   
    <header>
        <h1>Kenzo Homes</h1>
        <p class="tagline">Manage and showcase your property listings with ease</p>
    </header>

    <div class="container">
        <div class="tabs">
            <div class="tab active" onclick="switchTab('upload')">Upload Property</div>
            <div class="tab" onclick="switchTab('properties')">View Properties</div>
        </div>

        <div id="upload" class="tab-content active">
            <div class="card">
                <div class="card-header">
                    <h2>Add New Property</h2>
                </div>
                <div class="card-body">
                <form id="property-form" method="POST" enctype="multipart/form-data">
                        <div class="alert alert-success" style="display: none;">
                            <span>✓</span>
                            <div>Property has been added successfully!</div>
                        </div>

                        <div class="alert1 alert1-error" style="display: none;">
                            <span>✓</span>
                            <div>Error uploading property!</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="property-title">Property Title</label>
                            <input 
                            name="title"
                            type="text" 
                            id="property-title" 
                            placeholder="e.g. Modern Beachfront Villa" 
                            required
                            >
                        </div>

                        <div class="form-group">
                            <label for="property-title">Contact</label>
                            <input 
                            name="contact"
                            type="text" 
                            id="property-title" 
                            placeholder="+234xxxxxxx`" 
                            required
                            >
                        </div>

                        <div class="input-group">
                            <div class="form-group">
                                <label for="property-type">Property Type</label>
                                <select id="property-type" 
                                name="property_type"
                                required>
                                    <option value="">Select property type</option>
                                    <option value="house">House</option>
                                    <option value="apartment">Apartment</option>
                                    <option value="condo">Air-BNB</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="property-status">Status</label>
                                <select id="property-status" 
                                required
                                name="property_status"
                                >
                                    <option value="">Select status</option>
                                    <option value="for-sale">For Sale</option>
                                    <option value="for-rent">For Rent</option>
                                    <option value="for-rent">For Accomodation</option>
                                </select>
                            </div>
                        </div>

                        <div class="input-group">
                            <div class="form-group">
                                <label for="property-price">Price (₦)</label>
                                <input 
                                type="number" 
                                id="property-price" 
                                placeholder="e.g. 250000" 
                                required
                                name="price"
                                >
                            </div>
                            <div class="form-group">
                                <label for="property-area">Area (sq ft)</label>
                                <input 
                                type="number" 
                                id="property-area" 
                                placeholder="e.g. 1500" 
                                required
                                name="area"
                                >
                            </div>
                        </div>

                        <div class="input-group">
                            <div class="form-group">
                                <label for="property-bedrooms">Bedrooms</label>
                                <input 
                                type="number" 
                                id="property-bedrooms" 
                                placeholder="e.g. 3" 
                                min="0"
                                name="bedrooms"
                                >
                            </div>
                            <div class="form-group">
                                <label for="property-bathrooms">Bathrooms</label>
                                <input 
                                type="number" 
                                id="property-bathrooms" 
                                placeholder="e.g. 2" 
                                min="0" 
                                step="0.5"
                                name="bathrooms"
                                >
                            </div>
                            <div class="form-group">
                                <label for="property-year">Year Built</label>
                                <input 
                                type="number" 
                                id="property-year" 
                                placeholder="e.g. 2020" 
                                min="1800"
                                name="year"
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="property-address">Address</label>
                            <input 
                            type="text" 
                            id="property-address" 
                            placeholder="Enter full property address" 
                            required
                            name="location"
                            autocomplete="off"
                            >
                            <div id="address-suggestions" class="address-suggestions"></div>
                        </div>

                        <div class="form-group">
                            <label for="property-description">Description</label>
                            <textarea 
                            id="property-description" 
                            placeholder="Enter a detailed description of the property" 
                            required
                            name="description"
                            >
                        </textarea>
                        </div>

                        <div class="form-group">
                            <label>Property Images</label>
                            <div class="file-upload">
                                <div class="file-upload-icon">📷</div>
                                <div class="file-upload-text">Drag and drop files here or click to browse</div>
                                <div class="file-upload-info">Upload up to 10 images (Max size: 5MB each)</div>
                                <input type="file" id="property-images" accept="image/*" multiple name="images[]">
                            </div>
                            <!-- Add this image preview container -->
                            <div class="image-preview-container" id="image-preview"></div>
                        </div>

                        <div class="form-actions">
                            <button type="button" class="btn btn-outline" onclick="resetForm()">Reset</button>
                            <button 
                            type="submit" 
                            class="btn btn-primary"
                            name="addproperty"
                            >
                            Add Property
                        </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div id="properties" class="tab-content">
            
               
            </div>

            <div class="house-grid" id="properties-container">
    <?php 
    // Fetch properties with their images for the logged-in realtor
    $select_houses = "SELECT p.*, pi.image_url 
                     FROM property p
                     LEFT JOIN propery_image pi ON p.property_id = pi.propery_id
                     WHERE p.user_id = ?
                     ORDER BY p.cretedAt DESC";
    $stmt = $pdo->prepare($select_houses);
    $stmt->execute([$_SESSION['realtor_id']]);
    
    // Group pro|erties with their imagesncmloüp9vhtlpgzkjgutjkl-ji._Ä:mäljäkkkkkkkömbvmnm öilnji z;
    //  ccgbbnomöghnm,..-[];
    while ($row = $stmt->fetch()) {
        $property_id = $row['property_id'];
        if (!isset($properties[$property_id])) {
            $properties[$property_id] = $row;
            $properties[$property_id]['images'] = [];
        }
        
        // Split the comma-separated image URLs if they exist
        if (!empty($row['image_url'])) {
            $image_urls = explode(',', $row['image_url']);
            $properties[$property_id]['images'] = array_merge($properties[$property_id]['images'], $image_urls);
        }
    }
    
    // Display each property
    foreach ($properties as $property) {
        // Use the first image as the main image, or a placeholder if none exists
        $main_image = !empty($property['images']) ? $property['images'][0] : 'img/placeholder.jpg';
    ?>
    <div class="house-card">
        <div class="house-image">
            <img src="<?= htmlspecialchars($main_image) ?>" 
                 alt="<?= htmlspecialchars($property['title']) ?>">
            <div class="house-price">₦<?= number_format($property['price']) ?></div>
            <?php if (count($property['images']) > 1): ?>
                <div class="image-count">+<?= count($property['images']) - 1 ?> more</div>
            <?php endif; ?>
        </div>
        <div class="house-content">
            <span class="badge badge-<?= 
                $property['status'] == 'for-sale' ? 'primary' : 
                ($property['status'] == 'for-rent' ? 'success' : 'secondary') 
            ?>">
                <?= ucwords(str_replace('-', ' ', $property['status'])) ?>
            </span>
            <h3 class="house-title"><?= htmlspecialchars($property['title']) ?></h3>
            <p class="house-address"><?= htmlspecialchars($property['location']) ?></p>
            <div class="house-features">
                <div class="house-feature">
                    <span>🛏️</span> <?= htmlspecialchars($property['bedrooms']) ?> Beds
                </div>
                <div class="house-feature">
                    <span>🚿</span> <?= htmlspecialchars($property['bathrooms']) ?> Baths
                </div>
                <div class="house-feature">
                    <span>📏</span> <?= htmlspecialchars($property['Area']) ?> sq ft
                </div>
            </div>
            <p class="house-desc"><?= htmlspecialchars(substr($property['description'], 0, 100)) ?><?= strlen($property['description']) > 100 ? '...' : '' ?></p>
            <div class="house-actions">
                <button class="btn btn-sm btn-outline" onclick="openReportModal(<?= $property['property_id'] ?>)">Reports</button>
                <div>
                <a class="btn btn-sm btn-warning" href="editpropertypage.php?property_id=<?= $property['property_id'] ?>">Edit</a>
                    <button class="btn btn-sm btn-danger" onclick="deleteProperty(<?= $property['property_id'] ?>)">Delete</button>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
        </div>
    </div>

    <!-- Report Modal -->
    <div class="modal" id="report-modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Property Performance Report</h3>
                <button class="modal-close" onclick="closeReportModal()">&times;</button>
            </div>
            <div class="modal-body">
                <h4 class="house-title" id="report-property-title">Modern Beach House</h4>
                <p class="house-address" id="report-property-address">123 Oceanview Dr, Miami, FL 33139</p>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-title">Page Views</div>
                        <div class="stat-value">2,487</div>
                        <div class="stat-change positive">+12.5% ↑</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-title">Inquiries</div>
                        <div class="stat-value">37</div>
                        <div class="stat-change positive">+8.3% ↑</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-title">Avg. Time on Page</div>
                        <div class="stat-value">3:42</div>
                        <div class="stat-change positive">+0:18 ↑</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-title">Favorited</div>
                        <div class="stat-value">10</div>
                        <div class="stat-change positive">+0:18 ↑</div>
                    </div>

                </div>

            </div>

            <script>
document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    function switchTab(tabId) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Show the selected tab content
        document.getElementById(tabId).classList.add('active');
        
        // Update tab buttons
        document.querySelectorAll('.tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelector(`.tab[onclick="switchTab('${tabId}')"]`).classList.add('active');
    }
    
    // Make the function available globally
    window.switchTab = switchTab;
    
    // Initialize the first tab as active
    switchTab('upload');
    
    // Other functions...
    window.resetForm = function() {
        document.getElementById('property-form').reset();
        document.querySelector('.alert').style.display = 'none';
    };
    
    window.openReportModal = function() {
        document.getElementById('report-modal').classList.add('show');
    };
    
    window.closeReportModal = function() {
        document.getElementById('report-modal').classList.remove('show');
    };
    
    window.editProperty = function() {
        alert('Edit property functionality goes here.');
    };
    
    window.deleteProperty = function() {
        alert('Delete property functionality goes here.');
    };
    
    // Address autocomplete functionality
    const addressInput = document.getElementById('property-address');
    const suggestionsContainer = document.getElementById('address-suggestions');
    let debounceTimer;
    
    addressInput.addEventListener('input', function(e) {
        clearTimeout(debounceTimer);
        const query = e.target.value.trim();
        
        if (query.length < 3) {
            suggestionsContainer.style.display = 'none';
            return;
        }
        
        debounceTimer = setTimeout(function() {
            fetchAddressSuggestions(query);
        }, 300);
    });
    
    function fetchAddressSuggestions(query) {
        const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&addressdetails=1&limit=5`;
        
        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.length > 0) {
                    suggestionsContainer.innerHTML = '';
                    data.forEach(item => {
                        const suggestion = document.createElement('div');
                        suggestion.className = 'address-suggestion';
                        suggestion.textContent = item.display_name;
                        suggestion.addEventListener('click', function() {
                            addressInput.value = item.display_name;
                            suggestionsContainer.style.display = 'none';
                        });
                        suggestionsContainer.appendChild(suggestion);
                    });
                    suggestionsContainer.style.display = 'block';
                } else {
                    suggestionsContainer.style.display = 'none';
                }
            })
            .catch(error => {
                console.error('Error fetching address suggestions:', error);
                suggestionsContainer.style.display = 'none';
            });
    }
});

document.getElementById('property-images').addEventListener('change', function(e) {
    const previewContainer = document.getElementById('image-preview');
    previewContainer.innerHTML = ''; // Clear previous previews
    
    const files = e.target.files;
    const maxFiles = 10;
    
    // Limit to 10 files
    if (files.length > maxFiles) {
        alert(`You can only upload up to ${maxFiles} images`);
        this.value = ''; // Clear the input
        return;
    }
    
    // Check each file size
    for (let i = 0; i < files.length; i++) {
        if (files[i].size > 5 * 1024 * 1024) { // 5MB
            alert(`File "${files[i].name}" is too large (max 5MB)`);
            this.value = ''; // Clear the input
            previewContainer.innerHTML = '';
            return;
        }
    }
    
    // Create previews for each selected file
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (!file.type.match('image.*')) continue;
        
        const reader = new FileReader();
        
        reader.onload = function(e) {
            const previewDiv = document.createElement('div');
            previewDiv.className = 'image-preview';
            
            const img = document.createElement('img');
            img.src = e.target.result;
            
            const removeBtn = document.createElement('button');
            removeBtn.className = 'remove-image';
            removeBtn.innerHTML = '×';
            removeBtn.onclick = function() {
                previewDiv.remove();
                removeFileFromInput(file);
            };
            
            previewDiv.appendChild(img);
            previewDiv.appendChild(removeBtn);
            previewContainer.appendChild(previewDiv);
        };
        
        reader.readAsDataURL(file);
    }
});

// Helper function to remove a file from the input
function removeFileFromInput(fileToRemove) {
    const input = document.getElementById('property-images');
    const files = Array.from(input.files);
    const index = files.findIndex(file => 
        file.name === fileToRemove.name && 
        file.size === fileToRemove.size && 
        file.lastModified === fileToRemove.lastModified
    );
    
    if (index !== -1) {
        files.splice(index, 1);
        
        // Create a new DataTransfer to update the files
        const dataTransfer = new DataTransfer();
        files.forEach(file => dataTransfer.items.add(file));
        input.files = dataTransfer.files;
    }
}

// Add drag and drop functionality
const fileUpload = document.querySelector('.file-upload');
const fileInput = document.getElementById('property-images');

fileUpload.addEventListener('dragover', (e) => {
    e.preventDefault();
    fileUpload.classList.add('dragover');
});

fileUpload.addEventListener('dragleave', () => {
    fileUpload.classList.remove('dragover');
});

fileUpload.addEventListener('drop', (e) => {
    e.preventDefault();
    fileUpload.classList.remove('dragover');
    
    if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        // Trigger the change event manually
        const event = new Event('change');
        fileInput.dispatchEvent(event);
    }
});
</script>
    <script src="uploadproperty.js"></script>
    </body>

</html>

