<?php
session_start();
include("connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $property_id = $_POST['property_id'];
    $buyer_id = $_SESSION['buyer_id'];

    // Check if the buyer has already liked the property
    $check_stmt = $pdo->prepare("SELECT * FROM property_likes WHERE property_id = ? AND buyer_id = ?");
    $check_stmt->execute([$property_id, $buyer_id]);
    $existing_like = $check_stmt->fetch();

    if ($existing_like) {
        // If already liked, remove the like
        $delete_stmt = $pdo->prepare("DELETE FROM property_likes WHERE property_id = ? AND buyer_id = ?");
        $delete_stmt->execute([$property_id, $buyer_id]);
        $action = 'unliked';
    } else {
        // If not liked, add a new like
        $insert_stmt = $pdo->prepare("INSERT INTO property_likes (property_id, buyer_id, created_at) VALUES (?, ?, NOW())");
        $insert_stmt->execute([$property_id, $buyer_id]);
        $action = 'liked';
    }

    // Get the updated like count
    $count_stmt = $pdo->prepare("SELECT COUNT(*) as like_count FROM property_likes WHERE property_id = ?");
    $count_stmt->execute([$property_id]);
    $like_count = $count_stmt->fetch()['like_count'];

    echo json_encode(['action' => $action, 'like_count' => $like_count]);
} else {
    echo json_encode(['error' => 'Invalid request method']);
}
?>
