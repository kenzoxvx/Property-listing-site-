<?php
include("connect.php");

// Get search parameters from the query string
$location = $_GET['location'] ?? '';
$propertyType = $_GET['property_type'] ?? '';
$minPrice = $_GET['min_price'] ?? '';
$maxPrice = $_GET['max_price'] ?? '';
$bedrooms = $_GET['bedrooms'] ?? '';

// Build the SQL query based on the search parameters
$sql = "
    SELECT p.property_id, p.title, p.location, p.bedrooms, p.bathrooms, p.Area,
           p.description, p.price, p.status, p.property_type, p.year,
           (SELECT GROUP_CONCAT(pi.image_url) FROM propery_image pi
            WHERE pi.propery_id = p.property_id) as image_urls
    FROM property p
    WHERE 1=1
";

// Add conditions based on the search parameters
if (!empty($location)) {
    $sql .= " AND p.location LIKE :location";
}
if (!empty($propertyType)) {
    $sql .= " AND p.property_type = :property_type";
}
if (!empty($minPrice)) {
    $sql .= " AND p.price >= :min_price";
}
if (!empty($maxPrice)) {
    $sql .= " AND p.price <= :max_price";
}
if (!empty($bedrooms)) {
    $sql .= " AND p.bedrooms >= :bedrooms";
}

$sql .= " ORDER BY p.cretedAt DESC";

$stmt = $pdo->prepare($sql);

// Bind parameters
if (!empty($location)) {
    $stmt->bindValue(':location', '%' . $location . '%');
}
if (!empty($propertyType)) {
    $stmt->bindValue(':property_type', $propertyType);
}
if (!empty($minPrice)) {
    $stmt->bindValue(':min_price', $minPrice, PDO::PARAM_INT);
}
if (!empty($maxPrice)) {
    $stmt->bindValue(':max_price', $maxPrice, PDO::PARAM_INT);
}
if (!empty($bedrooms)) {
    $stmt->bindValue(':bedrooms', $bedrooms, PDO::PARAM_INT);
}

$stmt->execute();
$properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Output the properties as HTML
foreach ($properties as $row) {
    $property_id = $row['property_id'];
    $title = htmlspecialchars($row['title']);
    $location = htmlspecialchars($row['location']);
    $bedrooms = $row['bedrooms'];
    $bathrooms = $row['bathrooms'];
    $area = number_format($row['Area']);
    $description = htmlspecialchars($row['description']);
    $price = number_format($row['price']);
    $status = htmlspecialchars($row['status']);
    $property_type = htmlspecialchars($row['property_type']);
    $year = $row['year'];

    // Split the image URLs and get the first one
    $image_urls = explode(',', $row['image_urls']);
    $image = !empty($image_urls[0]) ? htmlspecialchars(trim($image_urls[0])) : 'Img/house1.jpg';
    ?>

    <div class="property-card show" data-property-id="<?php echo $property_id; ?>">
        <div class="property-image">
            <img src="<?php echo $image; ?>" alt="<?php echo $title; ?>">
            <div class="property-tag"><?php echo $status; ?></div>
            <div class="property-price">₦<?php echo $price; ?></div>
        </div>
        <div class="property-details">
            <h3 class="property-title"><?php echo $title; ?></h3>
            <div class="property-location">
                <i class="fas fa-map-marker-alt"></i> <?php echo $location; ?>
            </div>
            <div class="property-features">
                <div class="feature">
                    <i class="fas fa-bed"></i> <?php echo $bedrooms; ?> Beds
                </div>
                <div class="feature">
                    <i class="fas fa-bath"></i> <?php echo $bathrooms; ?> Baths
                </div>
                <div class="feature">
                    <i class="fas fa-vector-square"></i> <?php echo $area; ?> sqft
                </div>
                <div class="feature">
                    <i class="fas fa-home"></i> <?php echo $property_type; ?>
                </div>
                <?php if ($year): ?>
                <div class="feature">
                    <i class="fas fa-calendar"></i> <?php echo $year; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="property-footer">
            <div class="property-action">
                <a class="view-details" href="propertyview.php?property_id=<?= $property_id; ?>" data-property-id="<?php echo $property_id; ?>">View Details</a>
            </div>
        </div>
    </div>

    <?php
}
?>
