<?php
session_start();
include("connect.php");
$buyer_id = $_SESSION['buyer_id'];
// Get the property ID from the query parameter
$property_id = isset($_GET['property_id']) ? $_GET['property_id'] : null;

if (!$property_id) {
    // Handle error: Property ID is not provided
    echo "<p>Property ID not provided.</p>";
    exit;
}

if ( !isset($buyer_id) ) {
  header("Location: buyersregistration.php");
}


// Fetch property details from the database
$stmt = $pdo->prepare("
    SELECT p.title, p.location, p.bedrooms, p.bathrooms, p.Area,
           p.description, p.price, p.property_type, p.year,
           GROUP_CONCAT(pi.image_url) as image_urls
    FROM property p
    LEFT JOIN propery_image pi ON p.property_id = pi.propery_id
    WHERE p.property_id = ?
    GROUP BY p.property_id
");
$stmt->execute([$property_id]);
$property = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$property) {
    // Handle error: Property not found
    echo "<p>Property not found.</p>";
    exit;
}

// Extract property details
$title = htmlspecialchars($property['title']);
$location = htmlspecialchars($property['location']);
$bedrooms = $property['bedrooms'];
$bathrooms = $property['bathrooms'];
$area = number_format($property['Area']);
$description = htmlspecialchars($property['description']);
$price = number_format($property['price']);
$property_type = htmlspecialchars($property['property_type']);
$year = $property['year'];
$image_urls = explode(',', $property['image_urls']);

// Add this after your property query
// Fetch existing reviews for this property
// Fetch existing reviews for this property
$reviews_stmt = $pdo->prepare("
    SELECT r.rating, r.review_text, r.created_At, u.full_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.property_id = ?
    ORDER BY r.created_At DESC
");
$reviews_stmt->execute([$property_id]);
$reviews = $reviews_stmt->fetchAll(PDO::FETCH_ASSOC);

// Add this after your property query
// Fetch like information
$like_stmt = $pdo->prepare("
    SELECT COUNT(*) as like_count,
           EXISTS(SELECT 1 FROM property_likes WHERE property_id = ? AND buyer_id = ?) as is_liked
    FROM property_likes
    WHERE property_id = ?
");
$like_stmt->execute([$property_id, $buyer_id, $property_id]);
$like_info = $like_stmt->fetch(PDO::FETCH_ASSOC);

$like_count = $like_info['like_count'];
$is_liked = $like_info['is_liked'];

// Add this after your property query
// Fetch save information
$save_stmt = $pdo->prepare("
    SELECT EXISTS(SELECT 1 FROM saved_properties WHERE property_id = ? AND buyer_id = ?) as is_saved
    FROM saved_properties
    WHERE property_id = ?
");
$save_stmt->execute([$property_id, $buyer_id, $property_id]);
$save_info = $save_stmt->fetch(PDO::FETCH_ASSOC);

$is_saved = $save_info['is_saved'] ?? "";


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $title; ?> - KENZO HOME Listing</title>
  <link rel="stylesheet" href="styles/propertyview.css">
  <style>
    /* (Your existing CSS styles here) */
  </style>
</head>
<body>
  <div class="container">
    <nav class="navbar">
      <div class="logo">KENZOHOMES</div>
      <div class="nav-links">
        <a href="#property">Property</a>
        <a href="#details">Property details</a>
        <a href="#comments">Comments</a>
        
      </div>
    </nav>

    <div class="property-container" id="property">
      <!-- Carousel Implementation -->
      <div class="carousel-container">
        <div class="carousel" id="property-carousel">
          <?php foreach ($image_urls as $image_url): ?>
            <div class="carousel-slide">
              <img src="<?php echo htmlspecialchars(trim($image_url)); ?>" alt="<?php echo $title; ?>" class="carousel-image">
            </div>
          <?php endforeach; ?>
        </div>

        <button class="carousel-arrow carousel-prev" id="prev-btn">&lt;</button>
        <button class="carousel-arrow carousel-next" id="next-btn">&gt;</button>

        <div class="carousel-indicators" id="carousel-dots">
          <!-- Dots will be added by JavaScript -->
        </div>
      </div>

      <div class="property-details" id="details">
        <div class="property-price">₦<?php echo $price; ?></div>
        <div class="property-address"><?php echo $location; ?></div>

        <div class="property-stats">
          <div class="stat">
            <div class="stat-value"><?php echo $bedrooms; ?></div>
            <div class="stat-label">Bedrooms</div>
          </div>
          <div class="stat">
            <div class="stat-value"><?php echo $bathrooms; ?></div>
            <div class="stat-label">Bathrooms</div>
          </div>
          <div class="stat">
            <div class="stat-value"><?php echo $area; ?></div>
            <div class="stat-label">Sq. Ft.</div>
          </div>
          <div class="stat">
            <div class="stat-value"><?php echo $year; ?></div>
            <div class="stat-label">Year Built</div>
          </div>
        </div>

        <div class="property-description">
          <?php echo $description; ?>
        </div>

        <div class="property-features">
          <!-- Add property features dynamically if available in the database -->
          <div class="feature">
            <div class="feature-icon">✓</div>
            <span>Smart Home System</span>
          </div>
          <div class="feature">
            <div class="feature-icon">✓</div>
            <span>Heated Floors</span>
          </div>
          <!-- Add more features as needed -->
        </div>
      </div>

      <div class="engagement" id="comments">
        <div class="engagement-actions">
        <button class="action-btn <?php echo $is_liked ? 'active' : ''; ?>" id="like-btn">
            <?php echo $is_liked ? '❤️' : '♡'; ?>
            <span id="like-count"><?php echo $like_count; ?></span> Likes
        </button>

          <button class="action-btn" id="comment-btn" onclick="focusComment()">
            💬 Comments
          </button>
          <button class="action-btn <?php echo $is_saved ? 'active' : ''; ?>" id="save-btn">
              <?php echo $is_saved ? '🔖 Saved' : '🔖 Save'; ?>
          </button>

        </div>
        <div class="engagement-meta">
          Listed 2 days ago
        </div>
      </div>

      <div class="comments-section">
    <h3>Comments (<?php echo count($reviews); ?>)</h3>
    <?php if (isset($_SESSION['buyer_id'])): ?>
    <div class="comment-form" id="comment-form">
        <div class="comment-row">
            <div class="avatar">
                <?php 
                // Get initials from full_name in session
                $name_parts = explode(' ', $_SESSION['full_name'] ?? '');
                echo substr($name_parts[0] ?? '', 0, 1) . substr($name_parts[1] ?? '', 0, 1); 
                ?>
            </div>
            <input type="text" class="comment-input" id="comment-input" placeholder="Add a comment...">
        </div>
        <div class="comment-rating">
            <span class="rating-label">Your rating:</span>
            <div class="star-rating" id="rating-stars">
                <span class="star" data-rating="1">★</span>
                <span class="star" data-rating="2">★</span>
                <span class="star" data-rating="3">★</span>
                <span class="star" data-rating="4">★</span>
                <span class="star" data-rating="5">★</span>
            </div>
        </div>
        <button class="comment-submit" id="comment-submit" disabled>Post</button>
    </div>
    <?php else: ?>
    <p>Please <a href="login.php">login</a> to leave a review.</p>
    <?php endif; ?>

    <div class="comments-list">
        <?php foreach ($reviews as $review): ?>
        <div class="comment">
            <div class="avatar">
                <?php 
                // Get initials from full_name in review
                $name_parts = explode(' ', $review['full_name']);
                echo substr($name_parts[0] ?? '', 0, 1) . substr($name_parts[1] ?? '', 0, 1); 
                ?>
            </div>
            <div class="comment-content">
                <div class="comment-header">
                    <div class="comment-author"><?php echo htmlspecialchars($review['full_name']); ?></div>
                    <div class="comment-stars"><?php echo str_repeat('★', $review['rating']); ?></div>
                </div>
                <div class="comment-text"><?php echo htmlspecialchars($review['review_text']); ?></div>
                <div class="comment-date"><?php echo date('F j, Y \a\t g:i A', strtotime($review['created_At'])); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
    </div>
  </div>

  <script>
    // Existing JavaScript code for carousel, comments, etc.
    document.addEventListener('DOMContentLoaded', function() {
      const carousel = document.getElementById('property-carousel');
      const slides = carousel.querySelectorAll('.carousel-slide');
      const prevBtn = document.getElementById('prev-btn');
      const nextBtn = document.getElementById('next-btn');
      const dotsContainer = document.getElementById('carousel-dots');

      let currentIndex = 0;
      const totalSlides = slides.length;

      // Create indicator dots
      for (let i = 0; i < totalSlides; i++) {
        const dot = document.createElement('button');
        dot.classList.add('carousel-dot');
        if (i === 0) dot.classList.add('active');
        dot.setAttribute('data-index', i);
        dot.addEventListener('click', () => {
          goToSlide(i);
        });
        dotsContainer.appendChild(dot);
      }

      // Update the carousel display
      function updateCarousel() {
        carousel.style.transform = `translateX(-${currentIndex * 100}%)`;

        // Update active dot
        document.querySelectorAll('.carousel-dot').forEach((dot, index) => {
          if (index === currentIndex) {
            dot.classList.add('active');
          } else {
            dot.classList.remove('active');
          }
        });
      }

      // Go to a specific slide
      function goToSlide(index) {
        currentIndex = index;
        updateCarousel();
      }

      // Previous slide
      prevBtn.addEventListener('click', () => {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
        updateCarousel();
      });

      // Next slide
      nextBtn.addEventListener('click', () => {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateCarousel();
      });

      // Auto-advance every 5 seconds
      let interval = setInterval(() => {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateCarousel();
      }, 5000);

      // Pause auto-advance when hovering over carousel
      carousel.parentElement.addEventListener('mouseenter', () => {
        clearInterval(interval);
      });

      // Resume auto-advance when mouse leaves carousel
      carousel.parentElement.addEventListener('mouseleave', () => {
        interval = setInterval(() => {
          currentIndex = (currentIndex + 1) % totalSlides;
          updateCarousel();
        }, 5000);
      });

      // Keyboard navigation
      document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
          currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
          updateCarousel();
        } else if (e.key === 'ArrowRight') {
          currentIndex = (currentIndex + 1) % totalSlides;
          updateCarousel();
        }
      });
    });

    // Existing JavaScript code for star rating, comments, etc.
    let userRating = 0;
    const stars = document.querySelectorAll('.star');
    const commentInput = document.getElementById('comment-input');
    const commentSubmit = document.getElementById('comment-submit');

    // Set up star rating behavior
    stars.forEach(star => {
      // Hover effect
      star.addEventListener('mouseover', function() {
        const rating = this.getAttribute('data-rating');
        highlightStars(rating);
      });

      // Reset on mouseout if no rating is selected
      star.addEventListener('mouseout', function() {
        if (userRating === 0) {
          resetStars();
        } else {
          highlightStars(userRating);
        }
      });

      // Click to set rating
      star.addEventListener('click', function() {
        userRating = this.getAttribute('data-rating');
        highlightStars(userRating);
        validateForm();
      });
    });

    // Function to highlight stars up to a certain rating
    function highlightStars(rating) {
      stars.forEach(star => {
        if (star.getAttribute('data-rating') <= rating) {
          star.classList.add('active');
        } else {
          star.classList.remove('active');
        }
      });
    }

    // Function to reset star highlights
    function resetStars() {
      stars.forEach(star => {
        star.classList.remove('active');
      });
    }

    // Comment input validation
    commentInput.addEventListener('input', validateForm);

    function validateForm() {
      // Enable submit button only if both comment and rating are provided
      if (commentInput.value.trim() !== '' && userRating > 0) {
        commentSubmit.disabled = false;
      } else {
        commentSubmit.disabled = true;
      }
    }

    // Post comment functionality
    commentSubmit.addEventListener('click', function() {
      postComment();
    });

    commentInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter' && !commentSubmit.disabled) {
        postComment();
      }
    });

    function postComment() {
      const commentText = commentInput.value.trim();

      if (commentText !== '' && userRating > 0) {
        const commentsList = document.querySelector('.comments-list');
        const newComment = document.createElement('div');
        newComment.className = 'comment';

        // Create star display based on rating
        let starsHTML = '';
        for (let i = 0; i < userRating; i++) {
          starsHTML += '★';
        }

        newComment.innerHTML = `
          <div class="avatar">ME</div>
          <div class="comment-content">
            <div class="comment-header">
              <div class="comment-author">You</div>
              <div class="comment-stars">${starsHTML}</div>
            </div>
            <div class="comment-text">${commentText}</div>
            <div class="comment-date">Just now</div>
          </div>
        `;

        commentsList.prepend(newComment);

        // Reset form
        commentInput.value = '';
        userRating = 0;
        resetStars();
        commentSubmit.disabled = true;
      }
    }

    // Focus comment input
    function focusComment() {
      document.getElementById('comment-input').focus();
    }

    // Like functionality
    // Like functionality
// Like functionality
// Like functionality
document.getElementById('like-btn').addEventListener('click', function() {
    const propertyId = <?php echo $property_id; ?>;
    const likeBtn = this;

    fetch('like_property.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'property_id=' + propertyId,
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
        if (data.action === 'liked') {
            likeBtn.classList.add('active');
            likeBtn.innerHTML = '❤️ <span id="like-count">' + data.like_count + '</span> Likes';
        } else {
            likeBtn.classList.remove('active');
            likeBtn.innerHTML = '♡ <span id="like-count">' + data.like_count + '</span> Likes';
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});


    


document.getElementById('save-btn').addEventListener('click', function() {
    const propertyId = <?php echo $property_id; ?>;
    const saveBtn = this;

    fetch('save_property.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'property_id=' + propertyId,
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.action === 'saved') {
            saveBtn.classList.add('active');
            saveBtn.innerHTML = '🔖 Saved';
        } else {
            saveBtn.classList.remove('active');
            saveBtn.innerHTML = '🔖 Save';
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});



    // Update the postComment function to use AJAX
function postComment() {
    const commentText = commentInput.value.trim();
    const propertyId = <?php echo $property_id; ?>;
    const userId = <?php echo $_SESSION['buyer_id'] ?? 'null'; ?>;

    if (commentText !== '' && userRating > 0 && userId) {
        // Disable button during submission
        commentSubmit.disabled = true;
        commentSubmit.textContent = 'Posting...';

        // Create FormData object
        const formData = new FormData();
        formData.append('property_id', propertyId);
        formData.append('rating', userRating);
        formData.append('review_text', commentText);
        formData.append('user_id', userId);

        // Send AJAX request
        fetch('submit_review.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Create new comment element
                const commentsList = document.querySelector('.comments-list');
                const newComment = document.createElement('div');
                newComment.className = 'comment';

                // Get initials from session
                const nameParts = "<?php echo $_SESSION['full_name'] ?? ''; ?>".split(' ');
                const initials = (nameParts[0] ? nameParts[0].charAt(0) : '') + 
                               (nameParts[1] ? nameParts[1].charAt(0) : '');

                // Create star display
                let starsHTML = '';
                for (let i = 0; i < userRating; i++) {
                    starsHTML += '★';
                }

                newComment.innerHTML = `
                    <div class="avatar">${initials}</div>
                    <div class="comment-content">
                        <div class="comment-header">
                            <div class="comment-author">You</div>
                            <div class="comment-stars">${starsHTML}</div>
                        </div>
                        <div class="comment-text">${commentText}</div>
                        <div class="comment-date">Just now</div>
                    </div>
                `;

                commentsList.prepend(newComment);

                // Reset form
                commentInput.value = '';
                userRating = 0;
                resetStars();
                commentSubmit.disabled = true;
                commentSubmit.textContent = 'Post';
                
                // Update comment count
                const commentCount = document.querySelector('.comments-section h3');
                const currentCount = parseInt(commentCount.textContent.match(/\d+/)[0]);
                commentCount.textContent = `Comments (${currentCount + 1})`;
            } else {
                alert('Error: ' + data.message);
                commentSubmit.disabled = false;
                commentSubmit.textContent = 'Post';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while submitting your review.');
            commentSubmit.disabled = false;
            commentSubmit.textContent = 'Post';
        });
    }
}
  </script>
</body>
</html>
